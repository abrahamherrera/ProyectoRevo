package Implementacion;
import Conexion.Conexion;
import Dominio.UsuarioSistema;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abraham
 */ 
public class UsuarioSistemaDAO implements IUsuarioSistemaDAO{
  private final Conexion conexion;
  private Connection connection;
  private ResultSet resultados;
  
  public UsuarioSistemaDAO(){
      conexion=new Conexion();
  }

    @Override
    public String IniciarSesion(UsuarioSistema usuario) {
      String tipoDeUsuario="ninguno";
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement ObtenerUsuarios=connection.prepareStatement("SELECT Tipo FROM UsuarioSistema WHERE Usuario=? AND Contrasena=?");
            ObtenerUsuarios.setString(1, usuario.getUsuario());
            ObtenerUsuarios.setString(2, usuario.getContrasena());
            resultados=ObtenerUsuarios.executeQuery();
            if(resultados.next()){
                tipoDeUsuario=resultados.getString("Tipo");
            }
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
      return tipoDeUsuario;
    }
    }