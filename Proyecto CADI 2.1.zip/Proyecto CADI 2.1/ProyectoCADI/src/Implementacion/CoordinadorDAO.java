/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Conexion.Conexion;
import Dominio.Actividad;
import Dominio.Aviso;
import Dominio.ExperienciaEducativa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abraham
 */
public class CoordinadorDAO implements ICoordinadorDAO{
    private final Conexion conexion;
    private Connection connection;
    private ResultSet resultados;
    private Statement consulta;
    public CoordinadorDAO(){
      conexion=new Conexion();
    }

    @Override
    public boolean CrearExperienciaEducativa(ExperienciaEducativa experienciaEdicativa) {
        
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean BorrarExperienciaEducativa(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean CrearActividadesParaExperienciaEducativa(Actividad actividadcadi) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean BorrarActividadesParaExperienciaEducativa(int id) {
        boolean actividadEliminada=false;
        try {
            connection=conexion.ObtenerConexion();
            PreparedStatement borrarActividad=connection.prepareStatement("Delete FROM Actividad WHERE ID_Actividad=?");
            borrarActividad.setInt(1, id);
            borrarActividad.execute();
            actividadEliminada=true;
        } catch (SQLException excepcion) {
            Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException excepcion) {
                Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
            }
        }
        return actividadEliminada;
    }

    @Override
    public boolean CrearAvisos(Aviso aviso) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean BorrarAvisos(int ID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Actividad> consultarActividades() {
        List<Actividad> actividades=new ArrayList<>();
        try {
            connection=conexion.ObtenerConexion();
            PreparedStatement ObtenerActividades=connection.prepareStatement("SELECT * FROM actividad");
            //ObtenerActividades.setString(1, matricula);
            resultados=ObtenerActividades.executeQuery();
            while(resultados.next()){
                 Actividad actividadDeAlumno=new Actividad();
                 actividadDeAlumno.setId(resultados.getString("ID_Actividad"));
                 actividadDeAlumno.setNombreActividad(resultados.getString("NombreActividad"));
                 actividadDeAlumno.setCupo(resultados.getString("cupo"));
                 actividadDeAlumno.setFechaFin(resultados.getString("Fecha"));
                 //actividadDeAlumno.setDescripcion(resultados.getString("Descripcion"));
                 actividades.add(actividadDeAlumno);
            }
        } catch (SQLException excepcion) {
            Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException excepcion) {
                Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
            }
        }
       return actividades;
    }
    
}
