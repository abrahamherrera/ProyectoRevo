/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Dominio.Actividad;
import Dominio.Alumno;
import Dominio.ExperienciaEducativa;
import Dominio.Seccion;
import Dominio.UsuarioSistema;
import java.util.List;

/**
 *
 * @author abraham
 */
public interface IAsesorDAO {
    public boolean calificarAlumno(double calificacion, String matricula);
    public List<Actividad> consultarActividades();
    public List<Seccion> consultarSecciones(int idUsuario);
    public List<ExperienciaEducativa> consultarExperienciaEducativaDeSecciones(int idUsuario);
    public List<Alumno> consultarAlumnosAsignados(int idUsuario, int indice);
    public String obtenerCalificacion(String matricula);
}
