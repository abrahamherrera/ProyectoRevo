package Implementacion;
import Conexion.Conexion;
import Dominio.Actividad;
import Dominio.Alumno;
import Dominio.ExperienciaEducativa;
import Dominio.InscripcionAlumno;
import Dominio.Seccion;
import Dominio.UsuarioSistema;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AsesorDAO implements IAsesorDAO{
    private final Conexion conexion;
    private Connection connection;
    private ResultSet resultados;
    private Statement consulta;
  
    public AsesorDAO(){
      conexion=new Conexion();
    }

    @Override
    public boolean calificarAlumno(double calificacion, String matricula) {
        boolean calificacionRegistrada=false;
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement RegistrarCalificacion=connection.prepareStatement("UPDATE Inscripcion SET Calificacion=? WHERE MatriculaAlumno=?");
            RegistrarCalificacion.setDouble(1, calificacion);
            RegistrarCalificacion.setString(2, matricula);
            RegistrarCalificacion.execute();
            calificacionRegistrada=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return calificacionRegistrada;
    }

    @Override
    public List<Actividad> consultarActividades() {
        List<Actividad> actividades=new ArrayList<>();
        try {
            connection=conexion.ObtenerConexion();
            PreparedStatement ObtenerActividades=connection.prepareStatement("SELECT * FROM Actividad");
            //ObtenerActividades.setString(1, matricula);
            resultados=ObtenerActividades.executeQuery();
            while(resultados.next()){
                 Actividad actividadDeAlumno=new Actividad();
                 actividadDeAlumno.setId(resultados.getString("ID_Actividad"));
                 actividadDeAlumno.setNombreActividad(resultados.getString("NombreActividad"));
                
                 actividadDeAlumno.setFechaFin(resultados.getString("Fecha"));
                 //actividadDeAlumno.setDescripcion(resultados.getString("Descripcion"));
                 actividades.add(actividadDeAlumno);
            }
        } catch (SQLException excepcion) {
            Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException excepcion) {
                Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
            }
        }
       return actividades;
    } 
    

    @Override
    public List<Seccion> consultarSecciones(int idAsesor) {
        List<Seccion> secciones=new ArrayList<>();
        try {
            connection=conexion.ObtenerConexion();
            PreparedStatement ObtenerActividades=connection.prepareStatement("SELECT * FROM Seccion where ID_usuario=?");
            ObtenerActividades.setInt(1, idAsesor);
            resultados=ObtenerActividades.executeQuery();
            while(resultados.next()){
                 Seccion seccionAsignada=new Seccion();
                 seccionAsignada.setId(resultados.getString("ID_Seccion"));
                 seccionAsignada.setCupo(resultados.getInt("Cupo"));
                 seccionAsignada.setIdExperienciaEducativa(resultados.getString("ID_ExperienciaEducativa"));
                 secciones.add(seccionAsignada);
            }
        } catch (SQLException excepcion) {
            Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException excepcion) {
                Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
            }
        }
       return secciones;
    }
    @Override
    public List<ExperienciaEducativa> consultarExperienciaEducativaDeSecciones(int idAsesor) {
        List<ExperienciaEducativa> experienciasEducativas=new ArrayList<>();
        try {
            connection=conexion.ObtenerConexion();
            PreparedStatement ObtenerActividades=connection.prepareStatement("SELECT * FROM ExperienciaEducativa JOIN Seccion ON Seccion.ID_ExperienciaEducativa=ExperienciaEducativa.ID_ExperienciaEducativa WHERE Seccion.ID_usuario=?");
            ObtenerActividades.setInt(1, idAsesor);
            resultados=ObtenerActividades.executeQuery();
            while(resultados.next()){
                 ExperienciaEducativa experienciaEducativaAsignada=new ExperienciaEducativa();
                 experienciaEducativaAsignada.setNombre(resultados.getString("Nombre"));
                 experienciasEducativas.add(experienciaEducativaAsignada);
            }
        } catch (SQLException excepcion) {
            Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException excepcion) {
                Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
            }
        }
       return experienciasEducativas;
    }

    @Override
    public List<Alumno> consultarAlumnosAsignados(int idUsuario, int indice) {
        List<Alumno> alumnos=new ArrayList<>();
        List<Seccion> seccionesAsignadas=new ArrayList<>();
        seccionesAsignadas=this.consultarSecciones(idUsuario);
        try {
            connection=conexion.ObtenerConexion();
            PreparedStatement ObtenerAlumnos=connection.prepareStatement("SELECT * FROM Alumno JOIN Inscripcion ON Inscripcion.MatriculaAlumno=Alumno.MatriculaAlumno WHERE Inscripcion.ID_Seccion=?");
            ObtenerAlumnos.setInt(1, indice);
            resultados=ObtenerAlumnos.executeQuery();
            while(resultados.next()){
                 Alumno alumnoAsignado=new Alumno();
                 alumnoAsignado.setNombreCompleto(resultados.getString("NombreCompleto"));
                 alumnoAsignado.setMatricula(resultados.getString("MatriculaAlumno"));
                 
                 alumnos.add(alumnoAsignado);
            }
        } catch (SQLException excepcion) {
            Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException excepcion) {
                Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
            }
        }
       return alumnos;
    }

    @Override
    public String obtenerCalificacion(String matricula) {
        double calificacionDouble=0;
        String calificacion;
        try {
            connection=conexion.ObtenerConexion();
            PreparedStatement ObtenerCal=connection.prepareStatement("SELECT * FROM Inscripcion WHERE MatriculaAlumno=?");
            ObtenerCal.setString(1, matricula);
            resultados=ObtenerCal.executeQuery();
            while(resultados.next()){
                calificacionDouble=resultados.getDouble("Calificacion");  
            }
        } catch (SQLException excepcion) {
            Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException excepcion) {
                Logger.getLogger(Actividad.class.getName()).log(Level.SEVERE, null, excepcion);
            }
        }
        calificacion=Double.toString(calificacionDouble);
        return calificacion;
    }




}


