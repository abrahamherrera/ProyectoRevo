package Implementacion;
import Dominio.UsuarioSistema;

/**
 *
 * @author abraham
 */
public interface IUsuarioSistemaDAO {
    public String IniciarSesion(UsuarioSistema usuario);
    
}

