
package Implementacion;

import Dominio.Actividad;
import Dominio.Aviso;
import Dominio.ExperienciaEducativa;
import java.util.List;

public interface ICoordinadorDAO {
    public boolean CrearExperienciaEducativa(ExperienciaEducativa experienciaEdicativa);
    public boolean BorrarExperienciaEducativa(int id);
    public boolean CrearActividadesParaExperienciaEducativa(Actividad actividadcadi);
    public boolean BorrarActividadesParaExperienciaEducativa(int id);
    public boolean CrearAvisos(Aviso aviso);
    public boolean BorrarAvisos(int id);
    public List<Actividad> consultarActividades();
}
