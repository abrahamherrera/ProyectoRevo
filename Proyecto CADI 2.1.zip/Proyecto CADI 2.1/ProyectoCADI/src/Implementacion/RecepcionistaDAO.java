package Implementacion;

import Conexion.Conexion;
import Dominio.Bitacora;
import Dominio.Alumno;
import Dominio.ExperienciaEducativa;
import Dominio.InscripcionAlumno;
import Dominio.Reservacion;
import Dominio.Seccion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**********************************************************/
/* Nombre: Abraham Asael Herrera Rodriguez                */
/* Fecha: 4 febrero 2017*/
/* Descripción: en esta parte se implementas los casos de uso basicos de el recepcionista */
/**********************************************************/
public class RecepcionistaDAO implements IRecepcionistaDAO{
  private final Conexion conexion;
  private Connection connection;
  private ResultSet resultados;
  
  public RecepcionistaDAO(){
      conexion=new Conexion();
  }
  
  public String ObtenerFecha(){
      Date date = new Date();
      DateFormat hourdateFormat = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
       
        return hourdateFormat.format(date);
  }
  
    /**********************************************************/
/* metodos importantes                                      */
/* nombre: RegistrarBitacora Del Alumno                     */
/*                                                          */
/* proposito: utilizado para que el alumno mediante el acesor
  registre las bitacoras que a realizado en el sistema para
  que el acesor pueda verlas                                */
/*                                                          */
/* Limitaciones: solo acepta objetos de tipo bitacora       */
/*                                                          */
/*** ********************************************************/
    @Override
    public boolean RegistrarBitacoraDeAlumno(Bitacora bitacora) {
        String fechaEntrega=ObtenerFecha();
        boolean bitacoraRegistrada=false;
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement RegistrarBitacora=connection.prepareStatement("INSERT INTO Bitacora (FechaEntrega,Estado,Comentario,MatriculaAlumno)VALUES(?,?,?,?)");
            RegistrarBitacora.setString(1, fechaEntrega);
            RegistrarBitacora.setString(2,bitacora.getEstado());
            RegistrarBitacora.setString(3,bitacora.getComentario());
            RegistrarBitacora.setString(4, bitacora.getAlumnoMatricula());
            RegistrarBitacora.execute();
            bitacoraRegistrada=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return bitacoraRegistrada;
    }
    
    
    /**********************************************************/
/* metodos importantes                                        */
/* nombre: RegistrarAlumno                                    */
/*                                                            */
/* proposito: el recepcionista registra los datos del alumno 
    en el sistema para que pueda utilizar todas sus funciones */
/*                                                            */
/* Limitaciones: solo acepta objetos del tipo alumno, 
    no valida que exista un usuario repetido                  */
/*                                                            */
/*** ******************************************************/
    @Override
    public boolean RegistrarAlumno(Alumno alumno) {
      boolean alumnoRegistrado=false;
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement RegistrarAlumno=connection.prepareStatement("INSERT INTO Alumno (MatriculaAlumno,NombreCompleto)VALUES(?,?)");
            RegistrarAlumno.setString(1, alumno.getMatricula());
            RegistrarAlumno.setString(2, alumno.getNombreCompleto());
            RegistrarAlumno.execute();
            alumnoRegistrado=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return alumnoRegistrado;
    }
    
    /**********************************************************/
/* metodos importantes */
/* nombre: inscribir alumno */
/* */
/* proposito: el recepcionista inscribe al alumno a una seccion a la cual el alumno quiera registrarse*/
/* */
/* Limitaciones: no verifica  el cupo de las secciones*/
/* */
/*** ******************************************************/
    @Override
    public boolean inscribirAlumno(InscripcionAlumno inscripcionAlumno) {
       boolean alumnoRegistrado=false;
       String estadoInscripcion="Activo";
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement RegistrarAlumno=connection.prepareStatement("INSERT INTO Inscripcion (`Estado`, `Calificacion`, `TipodeInscripcion`, `MatriculaAlumno`, `ID_Seccion`) VALUES (?,?,?,?,?)");
            RegistrarAlumno.setString(1, estadoInscripcion);
            RegistrarAlumno.setFloat(2, 0);
            RegistrarAlumno.setString(3, inscripcionAlumno.getTipoDeInscripcion());
            RegistrarAlumno.setString(4, inscripcionAlumno.getAlumnoMatricula());
            RegistrarAlumno.setString(5, inscripcionAlumno.getSeccionID());
            RegistrarAlumno.execute();
            alumnoRegistrado=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return alumnoRegistrado;
    }
    
/**********************************************************/
/* metodos importantes                                    */
/* nombre: desinscribir alumno                            */
/*                                                        */
/* proposito: cambiar el estado de una inscripcion a inactiva */
/*                                                         */
/* Limitaciones: debe existir una inscripcion activa       */
/*                                                         */
/**********************************************************/
    @Override
    public boolean DesinscribirAlumno(InscripcionAlumno inscripcionAlumno) {
        boolean alumnodesinscrito=false;
        String estadoInscripcion="Inactivo";
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement DesinscribirAlumno=connection.prepareStatement("UPDATE Inscripcion SET Estado=? WHERE MatriculaAlumno=? AND ID_Seccion=?");
            DesinscribirAlumno.setString(1, estadoInscripcion);
            DesinscribirAlumno.setString(2, inscripcionAlumno.getAlumnoMatricula());
            DesinscribirAlumno.setString(3, inscripcionAlumno.getSeccionID());
            DesinscribirAlumno.execute();
            alumnodesinscrito=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return alumnodesinscrito;
    }

    @Override
    public boolean RegistrarReservacion(Reservacion reservacion) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
/**********************************************************/
/* metodos importantes */
/* nombre: EliminarAlumno */
/* */
/* proposito: Borra los datos del alumno del sistema*/
/* */
/* Limitaciones: no borra sus demas datos(inscripciones,bitacoras)*/
/* */
/*** ******************************************************/
    @Override
    public boolean EliminarAlumno(Alumno alumno) {
        boolean alumnoEliminado=false;
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement EliminarAlumno=connection.prepareStatement("DELETE FROM Alumno WHERE MatriculaAlumno=?");//mejorar el borrar para que borre todos los registros
            EliminarAlumno.setString(1, alumno.getMatricula());
            EliminarAlumno.execute();
            alumnoEliminado=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return alumnoEliminado;
    }

    @Override
    public List<ExperienciaEducativa> ObtenerExperienciasEducativas() {
        List<ExperienciaEducativa> experienciaEducativas=new ArrayList<>();
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement ObtenerExperienciasEducativas=connection.prepareStatement("SELECT `ID_ExperienciaEducativa` FROM `ExperienciaEducativa`");
            resultados=ObtenerExperienciasEducativas.executeQuery();
            while(resultados.next()){
                ExperienciaEducativa experienciaEducativa=new ExperienciaEducativa();
                experienciaEducativa.setId(resultados.getString("ID_ExperienciaEducativa"));
                experienciaEducativas.add(experienciaEducativa);
            }
            
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return experienciaEducativas;
    }

    @Override
    public List<Seccion> ObtenerSecciones(String IDExperienciaEduativa) {
        List<Seccion> secciones=new ArrayList<>();
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement ObtenerExperienciasEducativas=connection.prepareStatement("SELECT `ID_Seccion` FROM `Seccion` WHERE ID_ExperienciaEducativa=?");
            ObtenerExperienciasEducativas.setString(1, IDExperienciaEduativa);
            resultados=ObtenerExperienciasEducativas.executeQuery();
            while(resultados.next()){
                Seccion seccion=new Seccion();
                seccion.setId(resultados.getString("ID_Seccion"));
                secciones.add(seccion);
            }
            
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return secciones;
    }

    @Override
    public List<InscripcionAlumno> ObtenerInscripciones(String Matricula) {
       List<InscripcionAlumno> secciones=new ArrayList<>();
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement ObtenerExperienciasEducativas=connection.prepareStatement("SELECT ID_Seccion FROM Inscripcion WHERE MatriculaAlumno=?");
            ObtenerExperienciasEducativas.setString(1, Matricula);
            resultados=ObtenerExperienciasEducativas.executeQuery();
            while(resultados.next()){
                InscripcionAlumno seccion=new InscripcionAlumno();
                seccion.setSeccionID(resultados.getString("ID_Seccion"));
                secciones.add(seccion);
            }
            
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return secciones;
    }

    @Override
    public boolean ComprobarAlumno(String Matricula){
          boolean comprobarAlumno=false;
        try {
            connection= conexion.ObtenerConexion();
            PreparedStatement ComprobarAlumno=connection.prepareStatement("SELECT MatriculaAlumno FROM Alumno WHERE MatriculaAlumno=?");
            ComprobarAlumno.setString(1, Matricula);
            resultados=ComprobarAlumno.executeQuery();
            while(resultados.next()){
                if (resultados.getString("MatriculaAlumno").equals(Matricula)) {
                comprobarAlumno=true;
            }
            }
            
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return comprobarAlumno;
    }
}
