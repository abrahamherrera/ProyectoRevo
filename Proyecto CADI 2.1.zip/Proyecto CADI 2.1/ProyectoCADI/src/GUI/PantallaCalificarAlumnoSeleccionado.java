package GUI;
import Implementacion.AsesorDAO;
import Implementacion.IAsesorDAO;
import javax.swing.JOptionPane;
public class PantallaCalificarAlumnoSeleccionado extends javax.swing.JFrame {
    public PantallaCalificarAlumnoSeleccionado(int idUsuarioActual, String matriculaActual) {
        idUsuario=idUsuarioActual;
        matricula=matriculaActual;
        initComponents();
        
    }

    private PantallaCalificarAlumnoSeleccionado() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        botonCalificar = new javax.swing.JButton();
        campoCalificacion = new javax.swing.JTextField();
        botonCerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setText("Elija la calificacion que se asignará");

        botonCalificar.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        botonCalificar.setText("Calificar");
        botonCalificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCalificarActionPerformed(evt);
            }
        });

        campoCalificacion.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        campoCalificacion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                campoCalificacionKeyTyped(evt);
            }
        });

        botonCerrar.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        botonCerrar.setText("Cerrar");
        botonCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCerrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(botonCerrar)
                        .addGap(71, 71, 71)
                        .addComponent(botonCalificar, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(campoCalificacion, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(campoCalificacion, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonCalificar)
                    .addComponent(botonCerrar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCalificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCalificarActionPerformed
        String cadena=this.campoCalificacion.getText();
        boolean validez=false;
        validez=this.validarDatosVacios(cadena);
        if(validez){
            validez=this.validarValorCadena(cadena);
            if(validez){
                double calificacion= Double.parseDouble(cadena);
                IAsesorDAO asesorDAO=new AsesorDAO();
                validez=asesorDAO.calificarAlumno(calificacion, matricula);
                if(validez){
                    JOptionPane.showMessageDialog(null, "La calificación ha sido registrada");
                    this.setVisible(false);
                }else{
                    JOptionPane.showMessageDialog(null, "La calificación no pudo ser registrada, por favor contacte al administrador");
                }
            }  
        }
    }//GEN-LAST:event_botonCalificarActionPerformed

    private void campoCalificacionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoCalificacionKeyTyped
        if(campoCalificacion.getText().length()>=3){
        evt.consume();
        }
    }//GEN-LAST:event_campoCalificacionKeyTyped

    private void botonCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCerrarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_botonCerrarActionPerformed
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaCalificarAlumnoSeleccionado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaCalificarAlumnoSeleccionado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaCalificarAlumnoSeleccionado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaCalificarAlumnoSeleccionado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PantallaCalificarAlumnoSeleccionado().setVisible(true);
            }
        });
    }
    public boolean validarDatosVacios(String entrada){
        boolean datosValidos=false;
        if(entrada.isEmpty()){
            JOptionPane.showMessageDialog(null, "Ingrese un dato");
        }else{
            String calificacion=entrada;
            if((calificacion.equals(" "))||(calificacion.equals("  "))||(calificacion.equals("   "))){
                JOptionPane.showMessageDialog(null, "No ingrese espacios en blanco");
            }else{
               datosValidos=true;
                for (int i = 0; i < calificacion.length(); i++) {
                    if (Character.isWhitespace(calificacion.charAt(i))) { 
                        JOptionPane.showMessageDialog(null, "No ingrese espacios en blanco");
                        datosValidos=false;
                    }
                }
            }
        }
        return datosValidos;
    }
    public boolean validarValorCadena(String calificacion){
        boolean datosValidos=true;
        if ((calificacion.charAt(0)<=47)||(calificacion.charAt(0)>=58) ) {
            JOptionPane.showMessageDialog(null, "La calificacion debe empezar con un numero");
            datosValidos=false;
        }else{
            if(calificacion.length()==3){//123
                if(calificacion.charAt(1)=='.'){
                    if ((calificacion.charAt(2)<=47)||(calificacion.charAt(2)>=58) ) {
                        JOptionPane.showMessageDialog(null, "La calificacion debe terminar con un numero");
                        datosValidos=false;
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Ingrese un valor valido"); 
                    datosValidos=false;
                }
            }
            if((calificacion.length()==2)) {
                int calificacionEntero=Integer.parseInt(calificacion);
                if(calificacionEntero>10){
                    JOptionPane.showMessageDialog(null, "Ingrese un valor valido"); 
                    datosValidos=false;
                }
            }
        }
        return datosValidos;
    }
    int idUsuario;
    int indice;
    String matricula;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonCalificar;
    private javax.swing.JButton botonCerrar;
    private javax.swing.JTextField campoCalificacion;
    private javax.swing.JLabel jLabel1;
    // End of variables declaration//GEN-END:variables
}
/*
-Escritura de metodos
-Uso de Aserciones, programacion defensiva
-Uso de excepciones y errores
-tipos de integración
-Consultas parametrizadas, cuándo es recomendable?
-recomendaciones en terminos de principio para hacer un buen código
-complejidad, como reducir la complejidad, ocutalmiento de infromación, etc.
-ambito de variables y validación de entradas
-estructuras seguras en lugar de datos genericos, en lugar de usar una lista de objects, se utiliza una lista de una clase especifica
*/
