package Conexion;
 import java.sql.Connection;
 import java.sql.DriverManager;
 import java.sql.SQLException;
 import java.util.logging.Level;
 import java.util.logging.Logger;
public class Conexion {
    Connection conexion;
    private final String basededatos="jdbc:mysql://127.0.0.1/autoacceso";
    private final String usuario="cardex";
    private final String contrasena="c4rd3x";
    public Connection ObtenerConexion()throws SQLException{
        Conectar();
        return conexion;
    }

    private void Conectar() throws SQLException{
        conexion=DriverManager.getConnection(basededatos,usuario,contrasena);
    }
    public void Desconectar() throws SQLException{
        if(conexion!=null){
            try {
                if(!conexion.isClosed()){
                    conexion.close();
                }
            } catch (SQLException excepcion) {
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, excepcion);
            }
        }
    }
}
