/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.List;

/**
 *
 * @author abraham
 */
public class Seccion {
    private String idExperienciaEducativa;
    private String id;
    private int cupo;

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }
    /**
     * @return the cupo
     */
    public int getCupo() {
        return cupo;
    }

    /**
     * @param cupo the cupo to set
     */
    public void setCupo(int cupo) {
        this.cupo = cupo;
    }

    /**
     * @return the idExperienciaEducativa
     */
    public String getIdExperienciaEducativa() {
        return idExperienciaEducativa;
    }

    /**
     * @param idExperienciaEducativa the idExperienciaEducativa to set
     */
    public void setIdExperienciaEducativa(String idExperienciaEducativa) {
        this.idExperienciaEducativa = idExperienciaEducativa;
    }
}
