/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author abraham
 */
public class InscripcionAlumno {
    private int IDInscripcion;
    private String estado;
    private String tipoDeInscripcion;
    private double calificacion;
    private String alumnoMatricula;
    private String seccionID;

    /**
     * @return the IDInscripcion
     */
    public int getIDInscripcion() {
        return IDInscripcion;
    }

    /**
     * @param IDInscripcion the IDInscripcion to set
     */
    public void setIDInscripcion(int IDInscripcion) {
        this.IDInscripcion = IDInscripcion;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return the tipoDeInscrpcion
     */
    public String getTipoDeInscripcion() {
        return tipoDeInscripcion;
    }

    /**
     * @param tipoDeInscrpcion the tipoDeInscrpcion to set
     */
    public void setTipoDeInscripcion(String tipoDeInscrpcion) {
        this.tipoDeInscripcion = tipoDeInscrpcion;
    }

    /**
     * @return the calificacion
     */
    public double getCalificacion() {
        return calificacion;
    }

    /**
     * @param calificacion the calificacion to set
     */
    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }

    /**
     * @return the alumnoMatricula
     */
    public String getAlumnoMatricula() {
        return alumnoMatricula;
    }

    /**
     * @param alumnoMatricula the alumnoMatricula to set
     */
    public void setAlumnoMatricula(String alumnoMatricula) {
        this.alumnoMatricula = alumnoMatricula;
    }

    /**
     * @return the seccionID
     */
    public String getSeccionID() {
        return seccionID;
    }

    /**
     * @param seccionID the seccionID to set
     */
    public void setSeccionID(String seccionID) {
        this.seccionID = seccionID;
    }

    
}
