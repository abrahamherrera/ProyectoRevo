/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;


/**
 *
 * @author abraham
 */
public class Bitacora {
    private int idBitacora;
    private String fechaEntrega;
    private String comentario;
    private String estado;
    private String AlumnoMatricula;

    /**
     * @return the idBitacora
     */
    public int getIdBitacora() {
        return idBitacora;
    }

    /**
     * @param idBitacora the idBitacora to set
     */
    public void setIdBitacora(int idBitacora) {
        this.idBitacora = idBitacora;
    }

    /**
     * @return the fechaEntrega
     */
    public String getFechaEntrega() {
        return fechaEntrega;
    }

    /**
     * @param fechaEntrega the fechaEntrega to set
     */
    public void setFechaEntrega(String fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    /**
     * @return the comentario
     */
    public String getComentario() {
        return comentario;
    }

    /**
     * @param comentario the comentario to set
     */
    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return the AlumnoMatricula
     */
    public String getAlumnoMatricula() {
        return AlumnoMatricula;
    }

    /**
     * @param AlumnoMatricula the AlumnoMatricula to set
     */
    public void setAlumnoMatricula(String AlumnoMatricula) {
        this.AlumnoMatricula = AlumnoMatricula;
    }

  

   
}
