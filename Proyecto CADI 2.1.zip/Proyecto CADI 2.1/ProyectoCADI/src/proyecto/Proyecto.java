package proyecto;

import GUI.PantallaInicioSesion;

public class Proyecto {
    public static void main(String[] args) {
        new PantallaInicioSesion().setVisible(true);
      
    }
}
