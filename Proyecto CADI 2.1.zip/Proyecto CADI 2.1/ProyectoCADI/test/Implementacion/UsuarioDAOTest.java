/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Dominio.UsuarioSistema;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author abraham
 */
public class UsuarioDAOTest {
    
    public UsuarioDAOTest() {
    }
    
   
    /**
     * Test of IniciarSesion method, of class UsuarioDAO.
     */
    @Test
    public void testAutenticar() {
       UsuarioSistema usuario = new UsuarioSistema();
        UsuarioSistemaDAO instance = new UsuarioSistemaDAO();
        usuario.setContrasena("leafeon.");
        usuario.setUsuario("Yami");
        String result = instance.IniciarSesion(usuario);
        assertEquals("Coordinador", result);
    }
    
}
