/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Dominio.Alumno;
import Dominio.Bitacora;
import Dominio.ExperienciaEducativa;
import Dominio.InscripcionAlumno;
import Dominio.Seccion;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author abraham
 */
public class RecepcionistaDAOTest {
    
    public RecepcionistaDAOTest() {
    }
    
  


    /**
     * Test of RegistrarBitacoraDeAlumno method, of class RecepcionistaDAO.
     */
    @Test
    public void testRegistrarBitacoraDeAlumno() {
        RecepcionistaDAO recepcionista = new RecepcionistaDAO();
        Bitacora bitacora = new Bitacora();
        bitacora.setAlumnoMatricula("S14011621");
        bitacora.setEstado("a tiempo");
        bitacora.setComentario("chida bitacora");
        boolean result=recepcionista.RegistrarBitacoraDeAlumno(bitacora);
        assertEquals(result, true);
    }

    /**
     * Test of RegistrarAlumno method, of class RecepcionistaDAO.
     */
    @Test
    public void testRegistrarAlumno() {
        RecepcionistaDAO recepcionista = new RecepcionistaDAO();
        Alumno alumno = new Alumno();
        alumno.setMatricula("S14011622");
        alumno.setNombreCompleto("Yamilet Arrieta Mendoza");
        boolean result=recepcionista.RegistrarAlumno(alumno);
        assertEquals(result, true);
    }

    /**
     * Test of inscribirAlumno method, of class RecepcionistaDAO.
     */
    @Test
   public void testInscribirAlumno() {
        RecepcionistaDAO recepcionista = new RecepcionistaDAO();
        InscripcionAlumno inscripcion = new InscripcionAlumno();
        inscripcion.setAlumnoMatricula("S14011622");
        inscripcion.setCalificacion(0);
        inscripcion.setSeccionID("IBAS_1/1");
        inscripcion.setTipoDeInscripcion("primera");
        boolean result=recepcionista.inscribirAlumno(inscripcion);
        assertEquals(result, true);
    }

    /**
     * Test of DesinscribirAlumno method, of class RecepcionistaDAO.
     */
   @Test
    public void testDesinscribirAlumno() {
        RecepcionistaDAO recepcionista = new RecepcionistaDAO();
        InscripcionAlumno inscripcion = new InscripcionAlumno();
        inscripcion.setAlumnoMatricula("S14011622");
        inscripcion.setSeccionID("IBAS_1/1");
        boolean result=recepcionista.DesinscribirAlumno(inscripcion);
        assertEquals(result, true);
    }

    /**
     * Test of EliminarAlumno method, of class RecepcionistaDAO.
     */
   @Test
    public void testEliminarAlumno() {
      RecepcionistaDAO recepcionista = new RecepcionistaDAO();
      Alumno alumno = new Alumno();
      alumno.setMatricula("S14011622");
      boolean result=recepcionista.EliminarAlumno(alumno);
        assertEquals(result, true);
    }

    /**
     * Test of ObtenerExperienciasEducativas method, of class RecepcionistaDAO.
     */
    @Test
    public void testObtenerExperienciasEducativas() {
        RecepcionistaDAO recepcionista = new RecepcionistaDAO();
        List<ExperienciaEducativa>esperiencias = recepcionista.ObtenerExperienciasEducativas();
        assertEquals("prueba optener EE", esperiencias.size(), 5);
    }

    /**
     * Test of ObtenerSecciones method, of class RecepcionistaDAO.
     */
    @Test
    public void testObtenerSecciones() {
       RecepcionistaDAO recepcionista = new RecepcionistaDAO();
       List<Seccion>secciones = recepcionista.ObtenerSecciones("IBAS_1");
        assertEquals("prueba optener secciones", secciones.size(), 2);
    }

    /**
     * Test of ObtenerInscripciones method, of class RecepcionistaDAO.
     */
    @Test
    public void testObtenerInscripciones() {
        RecepcionistaDAO recepcionista= new RecepcionistaDAO();
        List<InscripcionAlumno> inscripciones= recepcionista.ObtenerInscripciones("S14011621");
        assertEquals("prueba optener inscripciones",inscripciones.size(),0);
    }

    /**
     * Test of ComprobarAlumno method, of class RecepcionistaDAO.
     */
    @Test
    public void testComprobarAlumno() {
        RecepcionistaDAO recepcionista= new RecepcionistaDAO();
        String matriculaEsperada="S14011621";
        recepcionista.ComprobarAlumno(matriculaEsperada);
        assertEquals("S14011621", matriculaEsperada);
    }
    
}
