/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author abraham
 */
public class InscripcionAlumno {
    private int IDInscripcion;
    private String estado;
    private String tipoDeInscrpcion;

    /**
     * @return the IDInscripcion
     */
    public int getIDInscripcion() {
        return IDInscripcion;
    }

    /**
     * @param IDInscripcion the IDInscripcion to set
     */
    public void setIDInscripcion(int IDInscripcion) {
        this.IDInscripcion = IDInscripcion;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * @return the tipoDeInscrpcion
     */
    public String getTipoDeInscrpcion() {
        return tipoDeInscrpcion;
    }

    /**
     * @param tipoDeInscrpcion the tipoDeInscrpcion to set
     */
    public void setTipoDeInscrpcion(String tipoDeInscrpcion) {
        this.tipoDeInscrpcion = tipoDeInscrpcion;
    }
    
}
