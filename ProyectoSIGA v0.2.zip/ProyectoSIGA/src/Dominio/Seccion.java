/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.List;

/**
 *
 * @author abraham
 */
public class Seccion {
    private int ib;
    private int cupo;

    /**
     * @return the ib
     */
    public int getIb() {
        return ib;
    }

    /**
     * @param ib the ib to set
     */
    public void setIb(int ib) {
        this.ib = ib;
    }

    /**
     * @return the cupo
     */
    public int getCupo() {
        return cupo;
    }

    /**
     * @param cupo the cupo to set
     */
    public void setCupo(int cupo) {
        this.cupo = cupo;
    }
}
