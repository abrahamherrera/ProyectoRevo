/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Dominio.Bitacora;
import Dominio.Alumno;
import Dominio.InscripcionAlumno;
import Dominio.Reservacion;

/**
 *
 * @author abraham
 */
public interface IRecepcionistaDAO {
    public boolean RegistrarBitacoraDeAlumno(Bitacora bitacora);
    public boolean RegistrarAlumno(Alumno alumno);
    public boolean RegistrarReservacion(Reservacion reservacion);
    public boolean inscribirAlumno(InscripcionAlumno inscripcionAlumno);
    public boolean DesinscribirAlumno(String Matricula);
}
