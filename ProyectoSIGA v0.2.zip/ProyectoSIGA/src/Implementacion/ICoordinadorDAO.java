/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Dominio.Actividad;
import Dominio.Aviso;
import Dominio.ExperienciaEducativa;

/**
 *
 * @author abraham
 */
public interface ICoordinadorDAO {
    public boolean CrearExperienciaEducativa(ExperienciaEducativa experienciaEdicativa);
    public boolean BorrarExperienciaEducativa(int ID);
    public boolean CrearActividadesParaExperienciaEducativa(Actividad actividadcadi);
    public boolean BorrarActividadesParaExperienciaEducativa(int ID);
    public boolean CrearAvisos(Aviso aviso);
    public boolean BorrarAvisos(int ID);
}
