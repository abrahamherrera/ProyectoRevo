/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Dominio.Bitacora;
import Dominio.UsuarioSistema;
import Dominio.Seccion;
import java.util.List;

/**
 *
 * @author abraham
 */
public class AsesorDao implements IAsesorDAO{

    @Override
    public float calificarAlumno(float calificacion) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Bitacora> ConsultarActividadesPorAlumno(String Matricula) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Seccion> ConsultarSeccionesAsignadas(UsuarioSistema usuarioSistema) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
