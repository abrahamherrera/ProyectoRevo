/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Dominio.UsuarioSistema;

/**
 *
 * @author abraham
 */
public interface IUsuarioSistemaDAO {
    public String IniciarSesion(UsuarioSistema usuario);
    
}
