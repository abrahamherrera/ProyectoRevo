/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Conexion.Conexion;
import Dominio.Bitacora;
import Dominio.Alumno;
import Dominio.InscripcionAlumno;
import Dominio.Reservacion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abraham
 */
public class RecepcionistaDAO implements IRecepcionistaDAO{
  private final Conexion conexion;
  private Connection connection;
  private ResultSet resultados;
  
  public RecepcionistaDAO(){
      conexion=new Conexion();
  }
  
  public String ObtenerFecha(){
      Date date = new Date();
      DateFormat hourdateFormat = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
       
        return hourdateFormat.format(date);
  }
  
    @Override
    public boolean RegistrarBitacoraDeAlumno(Bitacora bitacora) {
        String fechaEntrega=ObtenerFecha();
        boolean bitacoraRegistrada=false;
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement RegistrarBitacora=connection.prepareStatement("INSERT INTO Bitacora (FechaEntrega,Estado,Comentario,AlumnoMatricula)VALUES(?,?,?,?)");
            RegistrarBitacora.setString(1, fechaEntrega);
            RegistrarBitacora.setString(2,bitacora.getEstado());
            RegistrarBitacora.setString(3,bitacora.getEstado());
            RegistrarBitacora.setString(4, bitacora.getAlumnoMatricula());
            RegistrarBitacora.execute();
            bitacoraRegistrada=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return bitacoraRegistrada;
    }

    @Override
    public boolean RegistrarAlumno(Alumno alumno) {
      boolean alumnoRegistrado=false;
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement RegistrarAlumno=connection.prepareStatement("INSERT INTO Alumno (MatriculaAlumno,NombreCompleto)VALUES(?,?)");
            RegistrarAlumno.setString(1, alumno.getMatricula());
            RegistrarAlumno.setString(2, alumno.getNombreCompleto());
            RegistrarAlumno.execute();
            alumnoRegistrado=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return alumnoRegistrado;
    }

    @Override
    public boolean inscribirAlumno(InscripcionAlumno inscripcionAlumno) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean DesinscribirAlumno(String Matricula) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean RegistrarReservacion(Reservacion reservacion) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 
}
