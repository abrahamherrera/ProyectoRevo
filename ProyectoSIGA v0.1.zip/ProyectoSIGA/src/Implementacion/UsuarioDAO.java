/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Conexion.Conexion;
import Dominio.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abraham
 */ 
public class UsuarioDAO implements IUsuarioDAO{
  private final Conexion conexion;
  private Connection connection;
  static int coinciden=1;
  private ResultSet resultados;
  
  public UsuarioDAO(){
      conexion=new Conexion();
  }
    @Override
    public boolean IniciarSesion(Usuario usuario) {
        boolean existente=false;
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement ObtenerUsuarios=connection.prepareStatement("aqui va el sql");
            ObtenerUsuarios.setString(1, usuario.getUsuario());
            ObtenerUsuarios.setString(2, usuario.getContraseña());
            resultados=ObtenerUsuarios.executeQuery();
            if(resultados.next()){
                if(resultados.getInt(1)==coinciden)
                    existente=true;
            }
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
      return existente;
    }
}
