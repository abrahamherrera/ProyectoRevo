/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Dominio.Actividad;
import Dominio.Alumno;

/**
 *
 * @author abraham
 */
public interface IRecepcionistaDAO {
    public boolean RegistrarActividadDeAlumno(Actividad Actividad);
    public boolean InscribirAlumno(Alumno alumno);
    public boolean EliminarAlumno(String Matricula);
}
