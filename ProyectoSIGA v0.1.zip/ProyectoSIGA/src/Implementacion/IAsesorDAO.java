/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Implementacion;

import Dominio.Asesor;
import Dominio.Actividad;
import Dominio.Seccion;
import java.util.List;

/**
 *
 * @author abraham
 */
public interface IAsesorDAO {
    public float calificarAlumno(float calificacion);
    public List<Actividad> ConsultarActividadesPorAlumno(String Matricula);
    public List<Seccion> ConsultarSeccionesAsignadas(Asesor asesor);
}
