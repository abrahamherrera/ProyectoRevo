package Conexion;
 import java.sql.Connection;
 import java.sql.DriverManager;
 import java.sql.SQLException;
 import java.util.logging.Level;
 import java.util.logging.Logger;
/**
 *
 * @author abraham
 */
public class Conexion {
    Connection conexion;
    private final String basededatos="jdbc:mysql://127.0.0.1/autoacceso";
    private final String usuario="cardex";
    private final String contraseña="c4rd3x";
    
    public Connection OptenerConexion()throws SQLException{
        Conectar();
        return conexion;
    }

    private void Conectar() throws SQLException{
        conexion=DriverManager.getConnection(basededatos,usuario,contraseña);
    }
    public void Desconectar() throws SQLException{
        if(conexion!=null){
            try {
                if(!conexion.isClosed()){
                    conexion.close();
                }
            } catch (SQLException excepcion) {
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, excepcion);
            }
        }
    }
}
