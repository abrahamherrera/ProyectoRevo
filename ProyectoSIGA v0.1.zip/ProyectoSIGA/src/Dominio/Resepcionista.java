
package Dominio;
public class Resepcionista extends Usuario{


    /**
     * Todavia no se han encontrado atributos especificos para este actor
     */
    
}
