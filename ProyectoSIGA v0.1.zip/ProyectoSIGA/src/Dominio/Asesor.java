/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.List;

/**
 *
 * @author abraham
 */
public class Asesor extends Usuario{
   private List<Seccion> SeccionesAsignadas;
   
    public List<Seccion> getSeccionesAsignadas() {
        return SeccionesAsignadas;
    }

    /**
     * @param SeccionesAsignadas the SeccionesAsignadas to set
     */
    public void setSeccionesAsignadas(List<Seccion> SeccionesAsignadas) {
        this.SeccionesAsignadas = SeccionesAsignadas;
    }
}
