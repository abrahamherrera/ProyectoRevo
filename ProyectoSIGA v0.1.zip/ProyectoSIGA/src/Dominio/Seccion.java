/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.List;

/**
 *
 * @author abraham
 */
public class Seccion {
    private int ib;
    private List <Alumno> alumnos;
    private int cupo;

    /**
     * @return the ib
     */
    public int getIb() {
        return ib;
    }

    /**
     * @param ib the ib to set
     */
    public void setIb(int ib) {
        this.ib = ib;
    }

    /**
     * @return the alumnos
     */
    public List <Alumno> getAlumnos() {
        return alumnos;
    }

    /**
     * @param alumnos the alumnos to set
     */
    public void setAlumnos(List <Alumno> alumnos) {
        this.alumnos = alumnos;
    }

    /**
     * @return the cupo
     */
    public int getCupo() {
        return cupo;
    }

    /**
     * @param cupo the cupo to set
     */
    public void setCupo(int cupo) {
        this.cupo = cupo;
    }
}
