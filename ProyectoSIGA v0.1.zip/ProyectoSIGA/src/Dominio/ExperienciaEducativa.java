/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.List;

/**
 *
 * @author abraham
 */
public class ExperienciaEducativa {
    private int ID;
    private String Nombre;
    private List<Asesor> Asesores;
    private List<Seccion> secciones;

    /**
     * @return the ID
     */
    public int getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(int ID) {
        this.ID = ID;
    }

    /**
     * @return the Nombre
     */
    public String getNombre() {
        return Nombre;
    }

    /**
     * @param Nombre the Nombre to set
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * @return the Asesores
     */
    public List<Asesor> getAsesores() {
        return Asesores;
    }

    /**
     * @param Asesores the Asesores to set
     */
    public void setAsesores(List<Asesor> Asesores) {
        this.Asesores = Asesores;
    }

    /**
     * @return the secciones
     */
    public List<Seccion> getSecciones() {
        return secciones;
    }

    /**
     * @param secciones the secciones to set
     */
    public void setSecciones(List<Seccion> secciones) {
        this.secciones = secciones;
    }
}
