/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author abraham
 */
public class InscripcionAlumno {
    private int IDInscripcion;
    private String estado;
    private String tipoDeInscripcion;
    private float Calificacion;
    private String AlumnoMatricula;
    private String SeccionID;

    /**
     * @return the IDInscripcion
     */
    public int getIDInscripcion() {
        return IDInscripcion;
    }

    /**
     * @param IDInscripcion the IDInscripcion to set
     */
    public void setIDInscripcion(int IDInscripcion) {
        this.IDInscripcion = IDInscripcion;
    }

    /**
     * @return the estado
     */
    public String getEstado() {
        return estado;
    }

    /**
     * @param estado the estado to set
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

  

    /**
     * @return the Calificacion
     */
    public float getCalificacion() {
        return Calificacion;
    }

    /**
     * @param Calificacion the Calificacion to set
     */
    public void setCalificacion(float Calificacion) {
        this.Calificacion = Calificacion;
    }

    /**
     * @return the AlumnoMatricula
     */
    public String getAlumnoMatricula() {
        return AlumnoMatricula;
    }

    /**
     * @param AlumnoMatricula the AlumnoMatricula to set
     */
    public void setAlumnoMatricula(String AlumnoMatricula) {
        this.AlumnoMatricula = AlumnoMatricula;
    }

    /**
     * @return the SeccionID
     */
    public String getSeccionID() {
        return SeccionID;
    }

    /**
     * @param SeccionID the SeccionID to set
     */
    public void setSeccionID(String SeccionID) {
        this.SeccionID = SeccionID;
    }

    /**
     * @return the tipoDeInscripcion
     */
    public String getTipoDeInscripcion() {
        return tipoDeInscripcion;
    }

    /**
     * @param tipoDeInscripcion the tipoDeInscripcion to set
     */
    public void setTipoDeInscripcion(String tipoDeInscripcion) {
        this.tipoDeInscripcion = tipoDeInscripcion;
    }
    
}
