/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;



/**
 *
 * @author abraham
 */
public class Seccion {
    private String id;
    private int cupo;

    /**
     * @return the ib
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the ib to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the cupo
     */
    public int getCupo() {
        return cupo;
    }

    /**
     * @param cupo the cupo to set
     */
    public void setCupo(int cupo) {
        this.cupo = cupo;
    }
}