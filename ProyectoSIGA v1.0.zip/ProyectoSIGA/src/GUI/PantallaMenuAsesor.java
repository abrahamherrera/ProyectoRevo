/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import Dominio.UsuarioSistema;

/**
 *
 * @author Equipo
 */
public class PantallaMenuAsesor extends javax.swing.JFrame {

    /**
     * Creates new form PantallaMenuAsesor
     * @param usuario
     */
    public PantallaMenuAsesor(UsuarioSistema usuario) {
        initComponents();
        idUsuario=usuario.getID();
    }

    private PantallaMenuAsesor() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        botonCalificarAlumno = new javax.swing.JButton();
        botonConsultarActividades = new javax.swing.JButton();
        botonConsultarSecciones = new javax.swing.JButton();
        botonCerraSesion = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel1.setText("Menu Asesor");

        botonCalificarAlumno.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        botonCalificarAlumno.setText("Calificar Alumno");
        botonCalificarAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCalificarAlumnoActionPerformed(evt);
            }
        });

        botonConsultarActividades.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        botonConsultarActividades.setText("Consultar Actividades por Alumno");
        botonConsultarActividades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonConsultarActividadesActionPerformed(evt);
            }
        });

        botonConsultarSecciones.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        botonConsultarSecciones.setText("Consutltar Secciones Asignadas");
        botonConsultarSecciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonConsultarSeccionesActionPerformed(evt);
            }
        });

        botonCerraSesion.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        botonCerraSesion.setText("Cerrar Sesión");
        botonCerraSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCerraSesionActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel2.setText("Seleccione una opcion");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(102, 102, 102)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel1))
                            .addComponent(jLabel2)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonConsultarActividades)
                            .addComponent(botonConsultarSecciones)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(botonCalificarAlumno)
                                    .addComponent(botonCerraSesion))))))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(botonConsultarActividades)
                .addGap(18, 18, 18)
                .addComponent(botonConsultarSecciones)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botonCalificarAlumno)
                .addGap(18, 18, 18)
                .addComponent(botonCerraSesion)
                .addContainerGap(47, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonCalificarAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCalificarAlumnoActionPerformed
      
    }//GEN-LAST:event_botonCalificarAlumnoActionPerformed

    private void botonConsultarActividadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonConsultarActividadesActionPerformed
        
    }//GEN-LAST:event_botonConsultarActividadesActionPerformed

    private void botonCerraSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCerraSesionActionPerformed
        new PantallaInicioSesion().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_botonCerraSesionActionPerformed

    private void botonConsultarSeccionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonConsultarSeccionesActionPerformed

    }//GEN-LAST:event_botonConsultarSeccionesActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaMenuAsesor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaMenuAsesor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaMenuAsesor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaMenuAsesor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PantallaMenuAsesor().setVisible(true);
            }
        });
    }
    String idUsuario;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonCalificarAlumno;
    private javax.swing.JButton botonCerraSesion;
    private javax.swing.JButton botonConsultarActividades;
    private javax.swing.JButton botonConsultarSecciones;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
