package Implementacion;

import Conexion.Conexion;
import Dominio.Bitacora;
import Dominio.Alumno;
import Dominio.ExperienciaEducativa;
import Dominio.InscripcionAlumno;
import Dominio.Reservacion;
import Dominio.Seccion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author abraham
 */
public class RecepcionistaDAO implements IRecepcionistaDAO{
  private final Conexion conexion;
  private Connection connection;
  private ResultSet resultados;
  
  public RecepcionistaDAO(){
      conexion=new Conexion();
  }
  
  public String ObtenerFecha(){
      Date date = new Date();
      DateFormat hourdateFormat = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
       
        return hourdateFormat.format(date);
  }
  
    @Override
    public boolean RegistrarBitacoraDeAlumno(Bitacora bitacora) {
        String fechaEntrega=ObtenerFecha();
        boolean bitacoraRegistrada=false;
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement RegistrarBitacora=connection.prepareStatement("INSERT INTO Bitacora (FechaEntrega,Estado,Comentario,MatriculaAlumno)VALUES(?,?,?,?)");
            RegistrarBitacora.setString(1, fechaEntrega);
            RegistrarBitacora.setString(2,bitacora.getEstado());
            RegistrarBitacora.setString(3,bitacora.getComentario());
            RegistrarBitacora.setString(4, bitacora.getAlumnoMatricula());
            RegistrarBitacora.execute();
            bitacoraRegistrada=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return bitacoraRegistrada;
    }

    @Override
    public boolean RegistrarAlumno(Alumno alumno) {
      boolean alumnoRegistrado=false;
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement RegistrarAlumno=connection.prepareStatement("INSERT INTO Alumno (MatriculaAlumno,NombreCompleto)VALUES(?,?)");
            RegistrarAlumno.setString(1, alumno.getMatricula());
            RegistrarAlumno.setString(2, alumno.getNombreCompleto());
            RegistrarAlumno.execute();
            alumnoRegistrado=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return alumnoRegistrado;
    }

    @Override
    public boolean inscribirAlumno(InscripcionAlumno inscripcionAlumno) {
       boolean alumnoRegistrado=false;
       String estadoInscripcion="Activo";
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement RegistrarAlumno=connection.prepareStatement("INSERT INTO Inscripcion (`Estado`, `Calificacion`, `TipodeInscripcion`, `AlumnoMatricula`, `ID_Seccion`) VALUES (?,?,?,?,?)");
            RegistrarAlumno.setString(1, estadoInscripcion);
            RegistrarAlumno.setFloat(2, 0);
            RegistrarAlumno.setString(3, inscripcionAlumno.getTipoDeInscripcion());
            RegistrarAlumno.setString(4, inscripcionAlumno.getAlumnoMatricula());
            RegistrarAlumno.setString(5, inscripcionAlumno.getSeccionID());
            RegistrarAlumno.execute();
            alumnoRegistrado=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return alumnoRegistrado;
    }

    @Override
    public boolean DesinscribirAlumno(InscripcionAlumno inscripcionAlumno) {
        boolean alumnodesinscrito=false;
        String estadoInscripcion="Inactivo";
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement DesinscribirAlumno=connection.prepareStatement("UPDATE Inscripcion SET Estado=? WHERE MatriculaAlumno=? AND ID_Seccion=?");
            DesinscribirAlumno.setString(1, estadoInscripcion);
            DesinscribirAlumno.setString(2, inscripcionAlumno.getAlumnoMatricula());
            DesinscribirAlumno.setString(3, inscripcionAlumno.getSeccionID());
            DesinscribirAlumno.execute();
            alumnodesinscrito=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return alumnodesinscrito;
    }

    @Override
    public boolean RegistrarReservacion(Reservacion reservacion) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean EliminarAlumno(Alumno alumno) {
        boolean alumnoEliminado=false;
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement EliminarAlumno=connection.prepareStatement("DELETE FROM Alumno WHERE MatriculaAlumno=?");//mejorar el borrar para que borre todos los registros
            EliminarAlumno.setString(1, alumno.getMatricula());
            EliminarAlumno.execute();
            alumnoEliminado=true;
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return alumnoEliminado;
    }

    @Override
    public List<ExperienciaEducativa> ObtenerExperienciasEducativas() {
        List<ExperienciaEducativa> experienciaEducativas=new ArrayList<>();
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement ObtenerExperienciasEducativas=connection.prepareStatement("SELECT `ID_ExperienciaEducativa` FROM `ExperienciaEducativa`");
            resultados=ObtenerExperienciasEducativas.executeQuery();
            while(resultados.next()){
                ExperienciaEducativa experienciaEducativa=new ExperienciaEducativa();
                experienciaEducativa.setId(resultados.getString("ID_ExperienciaEducativa"));
                experienciaEducativas.add(experienciaEducativa);
            }
            
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return experienciaEducativas;
    }

    @Override
    public List<Seccion> ObtenerSecciones(String IDExperienciaEduativa) {
        List<Seccion> secciones=new ArrayList<>();
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement ObtenerExperienciasEducativas=connection.prepareStatement("SELECT `ID_Seccion` FROM `Seccion` WHERE ID_ExperienciaEducativa=?");
            ObtenerExperienciasEducativas.setString(1, IDExperienciaEduativa);
            resultados=ObtenerExperienciasEducativas.executeQuery();
            while(resultados.next()){
                Seccion seccion=new Seccion();
                seccion.setId(resultados.getString("ID_Seccion"));
                secciones.add(seccion);
            }
            
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return secciones;
    }

    @Override
    public List<InscripcionAlumno> ObtenerInscripciones(String Matricula) {
       List<InscripcionAlumno> secciones=new ArrayList<>();
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement ObtenerExperienciasEducativas=connection.prepareStatement("SELECT ID_Seccion FROM Inscripcion WHERE MatriculaAlumno=?");
            ObtenerExperienciasEducativas.setString(1, Matricula);
            resultados=ObtenerExperienciasEducativas.executeQuery();
            while(resultados.next()){
                InscripcionAlumno seccion=new InscripcionAlumno();
                seccion.setSeccionID(resultados.getString("ID_Seccion"));
                secciones.add(seccion);
            }
            
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        return secciones;
    }

    @Override
    public boolean ComprobarAlumno(String Matricula){
          boolean comprobarAlumno=false;
        try {
            connection= conexion.OptenerConexion();
            PreparedStatement ComprobarAlumno=connection.prepareStatement("SELECT MatriculaAlumno FROM Alumno WHERE MatriculaAlumno=?");
            ComprobarAlumno.setString(1, Matricula);
            resultados=ComprobarAlumno.executeQuery();
            while(resultados.next()){
                if (resultados.getString("MatriculaAlumno").equals(Matricula)) {
                comprobarAlumno=true;
            }
            }
            
        } catch (SQLException exception) {
            Logger.getLogger(IUsuarioSistemaDAO.class.getName()).log(Level.SEVERE,null, exception);
        }finally{
            try {
                conexion.Desconectar();
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioSistemaDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
       return comprobarAlumno;
    }
}
