package Conexion;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.SQLException;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author abraham
 */
public class ConexionTest {
    
  private final Conexion conexion;
  
  public ConexionTest(){
      conexion = new Conexion();
  }

    /**
     * Test of OptenerConexion method, of class Conexion.
     * @throws java.sql.SQLException
     */
    @Test
    public void PruebaConectarExitosa() throws SQLException {
        Connection connection = conexion.OptenerConexion();
        assertNotNull(connection);
    }

    /**
     * Test of desconectar method, of class Conexion.
     * @throws java.sql.SQLException
     */
    @Test
    public void PruebaDesconectarExitosa() throws SQLException {
        Connection connection = conexion.OptenerConexion();
        conexion.Desconectar();
        assertTrue(connection.isClosed());
    }
    
}
